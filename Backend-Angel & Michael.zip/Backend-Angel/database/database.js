const { v4: uuidv4 } = require('uuid');

const profesores = [
    {
        id: uuidv4(),
        nombre: 'Angel Castellanos',
    }
]

const materias = [
    {
        id: uuidv4(),
        nombre: 'Matematica',
        profesor: 'Angel Castellanos',
        secciones: ['A013'],
        eventos: ['Evaluacion 1.1']
    }
]

const secciones = [
    {
        id: uuidv4(),
        nombre: 'A013',
        materia: 'Matematica'
    }
]

const eventos = [
    {
        id: uuidv4(),
        titulo: 'Evaluacion 1.1',
        descipcion: 'xd',
        materia: 'Matematica',
        fecha: '10 feb 2024'
    }
]

module.exports = {
    profesores,
    materias,
    eventos,
    secciones
}