var express = require('express');
var router = express.Router();
const Eventos = require('../controller/eventos')

//Listar 2 semanas
router.get('/semanas', function (req, res, next) {
    Eventos.listarSemanas()
    .then((resultado) => {
        res.status(200).json({"status": 200, "mensaje": 'Se ha listado exitosamente los eventos de las siguientes dos semanas', "data": resultado})
    })
    .catch((error) => {
        res.status(400).json({"status": 400, "mensaje": error})
    })
});

//Listar eventos por materia de la semana
router.get('/listarSemanaMateria', function (req, res, next) {
    Eventos.listarSemanaMateria(req.body)
    .then((resultado) => {
        res.status(200).json({"status": 200, "mensaje": 'Se ha listado exitosamente los eventos de las siguiente semana de la materia seleccionada', "data": resultado})
    })
    .catch((error) => {
        console.log(error)
        res.status(400).json({"status": 400, "mensaje": error})
    })
});

//Agregar
router.post('/', function (req, res, next) {
    Eventos.agregar(req.body)
    .then((resultado) => {
        res.status(200).json({"status": 200, "data": resultado})
    })
    .catch((error) => {
        console.log(error)
        res.status(400).json({"status": 400, "mensaje": error})
    })
});

//Editar
router.put('/:id', function (req, res, next) {
    const { id } = req.params

    Eventos.editar(req.body, id)
    .then((resultado) => {
        res.status(200).json({"status": 200, "data": resultado})
    })
    .catch((error) => {
        console.log(error)
        res.status(400).json({"status": 400, "mensaje": error})
    })
});

//Eliminar
router.delete('/:id', function (req, res, next) {
    const { id } = req.params

    Eventos.eliminar(id)
    .then((resultado) => {
        res.status(200).json({"status": 200, "data": resultado})
    })
    .catch((error) => {
        console.log(error)
        res.status(400).json({"status": 400, "mensaje": error})
    })
});

module.exports = router;