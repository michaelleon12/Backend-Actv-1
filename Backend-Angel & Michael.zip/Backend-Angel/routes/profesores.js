var express = require('express');
var router = express.Router();
const Profesores = require('../controller/profesores')

//Agregar
router.post('/', function (req, res, next) {
    Profesores.agregar(req.body)
    .then((resultado) => {
        res.status(200).json({"status": 200, "data": resultado})
    })
    .catch((error) => {
        console.log(error)
        res.status(400).json({"status": 400, "mensaje": error})
    })
});

//listar 
router.get('/', function (req, res, next) {
    Profesores.listarMaterias()
    .then((resultado) => {
        res.status(200).json({"status": 200, "data": resultado, "mensaje": 'se ha listado exitosamente los profesores'})
    })
    .catch((error) => {
        console.log(error)
        res.status(400).json({"status": 400, "mensaje": error})
    })
});

module.exports = router;
