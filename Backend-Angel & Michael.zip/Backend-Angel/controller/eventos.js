const { eventos, materias } = require('../database/database');
const { v4: uuidv4 } = require('uuid');

class Evento {

    listarSemanaMateria(materia) {
        return new Promise((resolve, reject) => {
            if (!materia.nombre) {
                reject('Faltan propiedades escenciales: nombre')
            } else {
                const resultado = []

                const inicio = new Date();
                const UN_DIA_EN_MILISEGUNDOS = 1000 * 60 * 60 * 24;
                const INTERVALO = UN_DIA_EN_MILISEGUNDOS; // Cada dia
                const INTERVALO14 = UN_DIA_EN_MILISEGUNDOS * 7; // Cada dia
                const fin = new Date(inicio.getTime() + INTERVALO14);
                const formateadorFecha = new Intl.DateTimeFormat('es-MX', { dateStyle: 'medium', });
    
                for (let i = inicio; i <= fin; i = new Date(i.getTime() + INTERVALO)) {
    
                    for (let a = 0; a < eventos.length; a++) {
                        if (eventos[a].fecha == formateadorFecha.format(i)) {
                            if (materia.nombre === eventos[a].materia) {
                                resultado.push(eventos[a])
                            }
                        }
                    }
                }
    
                resolve(resultado)  
            }
        })
    }

    listarSemanas() {
        return new Promise((resolve, reject) => {
            const resultado = []

            const inicio = new Date();
            const UN_DIA_EN_MILISEGUNDOS = 1000 * 60 * 60 * 24;
            const INTERVALO = UN_DIA_EN_MILISEGUNDOS; // Cada dia
            const INTERVALO14 = UN_DIA_EN_MILISEGUNDOS * 14; // Cada dia
            const fin = new Date(inicio.getTime() + INTERVALO14);
            const formateadorFecha = new Intl.DateTimeFormat('es-MX', { dateStyle: 'medium', });

            for (let i = inicio; i <= fin; i = new Date(i.getTime() + INTERVALO)) {

                for (let a = 0; a < eventos.length; a++) {
                    if (eventos[a].fecha == formateadorFecha.format(i)) {
                        resultado.push(eventos[a])
                    }
                }
            }

            resolve(resultado)
        })
    }

    agregar(evento) {
        return new Promise((resolve, reject) => {
            if (!evento.titulo || !evento.materia || !evento.fecha || !evento.descipcion) {
                reject('Faltan propiedades escenciales: titulo, materia, fecha y descripcion')
            } else {
                for (let a = 0; a < eventos.length; a++) {
                    if (eventos[a].titulo === evento.titulo) {
                        return reject('Ya existe el evento')
                    }
                }

                let validar = true

                for (let i = 0; i < materias.length; i++) {
                    if (evento.materia === materias[i].nombre) {
                        materias[i].eventos.push(evento.titulo)
                        validar = false
                    }
                }

                if (validar) {
                    return reject('No existe la materia, debes ingresar una materia correcta')
                }

                const nuevoEvento = {
                    id: uuidv4(),
                    titulo: evento.titulo,
                    descipcion: evento.descipcion,
                    materia: evento.materia,
                    fecha: evento.fecha
                }

                eventos.push(nuevoEvento);
                resolve('Se ha agregado exitosamente el evento')
            }

        })
    }

    editar(evento, id) {
        return new Promise((resolve, reject) => {
            if (!evento.fecha || !evento.descipcion) {
                reject('Faltan propiedades escenciales: fecha y descripcion')
            } else {
                for (let i = 0; i < eventos.length; i++) {
                    if (eventos[i].id === id) {
                        eventos[i].fecha = evento.fecha
                        eventos[i].descipcion = evento.descipcion

                        return resolve('Se ha editado exitosamente el evento')
                    }
                }

                reject('No existe el evento que deseas editar')
            }

        })
    }

    eliminar(id) {
        return new Promise((resolve, reject) => {
            for (let i = 0; i < eventos.length; i++) {
                if (eventos[i].id === id) {

                    for (let e = 0; e < materias.length; e++) {
                        if (materias[e].nombre === eventos[i].materia) {

                            for (let a = 0; a < materias[e].eventos.length; a++) {
                                if (materias[e].eventos[a] === eventos[i].titulo) {
                                    materias[e].eventos.splice(a, 1)
                                }
                            }
                        }
                    }

                    eventos.splice(i, 1)
                    return resolve('has eliminado exitosamente el evento')
                }
            }

            reject('No existe el evento que deseas eliminar')
        })
    }
}

const eventosC = new Evento();
module.exports = eventosC;