const { secciones, materias } = require('../database/database');
const { v4: uuidv4 } = require('uuid');

class Seccion {

    agregar(seccion) {
        return new Promise ((resolve, reject) => {
            if (!seccion.nombre || !seccion.materia) {
                reject('Faltan propiedades escenciales: nombre y materia')
            } else {

                for (let a = 0; a < secciones.length; a++) {
                    if (secciones[a].nombre === seccion.nombre) {
                        return reject('Ya existe la seccion')
                    }
                }

                let validar = true

                for (let i = 0; i < materias.length; i++) {
                    if(seccion.materia === materias[i].nombre){
                        materias[i].secciones.push(seccion.nombre)
                        validar = false
                    }
                }
                
                if (validar) {
                    return reject('No existe la materia, debes ingresar una materia correcta')
                }

                const nuevaSeccion = {
                    id: uuidv4(),
                    nombre: seccion.nombre,
                    materia: seccion.materia,
                }
    
                secciones.push(nuevaSeccion);
                resolve('Se ha agregado exitosamente la seccion')
            }

        })
    }
}

const seccionesC = new Seccion();
module.exports = seccionesC;