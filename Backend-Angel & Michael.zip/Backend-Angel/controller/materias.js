const { materias, eventos, secciones, profesores } = require('../database/database');
const { v4: uuidv4 } = require('uuid');

class Materia {

    agregar(materia) {
        return new Promise ((resolve, reject) => {
            if (!materia.nombre || !materia.profesor) {
                reject('Faltan propiedades escenciales: nombre y profesor')
            } else {

                let existe = true

                for (let a = 0; a < profesores.length; a++) {
                    if (profesores[a].nombre === materia.profesor) {
                        existe = false
                    }
                }

                if (existe) {
                    return reject('No existe el profesor que deseas asignar la materia')
                }

                for (let e = 0; e < materias.length; e++) {
                    if (materias[e].nombre === materia.nombre) {
                        return reject('Ya existe la materia')
                    }
                }
                
                const nuevaMateria = {
                    id: uuidv4(),
                    nombre: materia.nombre,
                    profesor: materia.profesor,
                    secciones: [],
                    eventos: []
                }
    
                materias.push(nuevaMateria);
                resolve('Se ha agregado exitosamente la materia')
            }

        })
    }

    editar(materia, id) {
        return new Promise ((resolve, reject) => {
            if (!materia.nombre) {
                reject('Faltan propiedades escenciales: nombre')
            } else {
                for (let a = 0; a < materias.length; a++) {
                    if (materias[a].nombre === materia.nombre) {
                        return reject('Ya existe la materia con ese nombre')
                    }
                }

                for (let i = 0; i < materias.length; i++) {
                    if (materias[i].id === id) {
                        for (let ao = 0; ao < eventos.length; ao++) {
                            if (eventos[ao].materia === materias[i].nombre) {
                                eventos[ao].materia = materia.nombre
                            } 
                        }

                        for (let e = 0; e < secciones.length; e++) {
                            if (secciones[e].materia === materias[i].nombre) {
                                secciones[e].materia = materia.nombre
                            } 
                        }

                        materias[i].nombre = materia.nombre
                        return resolve('Se ha editado exitosamente la materia')
                    }
                }

                reject('No existe la materia que deseas editar')
            }

        })
    }

    editarProfesor(materia, id) {
        return new Promise ((resolve, reject) => {
            if (!materia.profesor) {
                reject('Faltan propiedades escenciales: profesor')
            } else {
                for (let i = 0; i < materias.length; i++) {
                    if (materias[i].id === id) {
                        
                        for (let e = 0; e < profesores.length; e++) {
                            if (profesores[e].nombre === materia.profesor) {

                                materias[i].profesor = materia.profesor
                                return resolve('Se ha editado exitosamente la materia')
                            }                            
                        }

                        return reject('No existe el profesor que deseas asignar a la materia')
                    }                    
                }

                reject('No existe la materia que deseas editar')
            }

        })
    }

    eliminarProfesor(id) {
        return new Promise ((resolve, reject) => {
            for (let i = 0; i < materias.length; i++) {
                if (materias[i].id === id) {
                    materias[i].profesor = 'Sin profesor'
                    return resolve('Se elimino exitosamente la asignacion del profesor a la materia ' + materias[i].nombre)
                }                
            }

            reject('No existe la materia')
        })
    }
}

const materiasC = new Materia();
module.exports = materiasC;