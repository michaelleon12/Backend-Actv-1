const { profesores, materias } = require('../database/database');
const { v4: uuidv4 } = require('uuid');

class Profesor {

    listarMaterias() {
        return new Promise ((resolve, reject) => {
           const resultado = []
           
           for (let i = 0; i < profesores.length; i++) {
                resultado.push({
                    profesor: profesores[i].nombre,
                    materias: []
                })
                
                for (let e = 0; e < materias.length; e++) {
                    if (materias[e].profesor === profesores[i].nombre) {
                        resultado[i].materias.push(materias[e].nombre)
                    }                    
                }
           }

           return resolve(resultado)
        })
    }

    agregar(profesor) {
        return new Promise ((resolve, reject) => {
            if (!profesor.nombre) {
                reject('Faltan propiedades escenciales: Nombre')
            } else {
                for (let a = 0; a < profesores.length; a++) {
                    if (profesores[a].nombre === profesor.nombre) {
                        return reject('Ya existe el profesor')
                    }
                }

                const nuevoProfesor = {
                    id: uuidv4(),
                    nombre: profesor.nombre,
                    materias: []
                }
    
                profesores.push(nuevoProfesor);
                resolve('Se ha agregado exitosamente el profesor')
            }

        })
    }
}

const profesoresC = new Profesor();
module.exports = profesoresC;